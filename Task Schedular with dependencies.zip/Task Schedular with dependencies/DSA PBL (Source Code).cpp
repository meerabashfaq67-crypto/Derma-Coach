#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <queue>
#include <sstream>
#include <thread>
#include <chrono>

// Task structure
struct Task {
    std::string name;
    int duration; // seconds
    std::vector<std::string> dependencies;
    bool completed = false;
};

// Global data structures
std::map<std::string, Task> taskMap; // Stores task details
std::map<std::string, std::vector<std::string>> adj; // Dependency graph
std::map<std::string, int> indegree; // Count unresolved dependencies

// Function to execute a task
void executeTask(const std::string &name) {
    std::cout << "\n? Executing task: " << name << " (" << taskMap[name].duration << "s)\n";
    std::this_thread::sleep_for(std::chrono::seconds(taskMap[name].duration));

    char answer;
    std::cout << "Task \"" << name << "\" finished. Did you complete it? (y/n): ";
    std::cin >> answer;
    std::cin.ignore(); // consume newline

    if (answer == 'y' || answer == 'Y') {
        taskMap[name].completed = true;
        std::cout << "? Task \"" << name << "\" completed!\n";
    } else {
        std::cout << "Please complete the task \"" << name << "\" again.\n";
        executeTask(name); // retry
    }
}

// Function to schedule tasks in topological order
void scheduleTasks() {
    std::queue<std::string> q;

    // Push tasks with no dependencies into the queue
    for (auto &pair : taskMap) {
        if (indegree[pair.first] == 0)
            q.push(pair.first);
    }

    // Process the queue
    while (!q.empty()) {
        std::string taskName = q.front();
        q.pop();

        executeTask(taskName);

        // Reduce indegree of dependent tasks
        for (const auto &next : adj[taskName]) {
            indegree[next]--;
            if (indegree[next] == 0) {
                q.push(next);
            }
        }
    }
}

int main() {
    int n;
    std::cout << "Enter number of tasks: ";
    std::cin >> n;
    std::cin.ignore(); // consume leftover newline

    // Input tasks
    for (int i = 0; i < n; ++i) {
        Task t;
        std::string deps;

        std::cout << "\nEnter task name: ";
        std::getline(std::cin, t.name);

        std::cout << "Enter duration (seconds): ";
        std::cin >> t.duration;
        std::cin.ignore();

        std::cout << "Enter dependencies (comma-separated, leave empty if none): ";
        std::getline(std::cin, deps);

        if (!deps.empty()) {
            std::stringstream ss(deps);
            std::string dep;
            while (std::getline(ss, dep, ',')) {
                dep.erase(0, dep.find_first_not_of(" \t"));
                dep.erase(dep.find_last_not_of(" \t") + 1);
                t.dependencies.push_back(dep);
                adj[dep].push_back(t.name);
            }
        }

        indegree[t.name] = t.dependencies.size();
        taskMap[t.name] = t;
    }

    std::cout << "\nScheduler started!\n";
    scheduleTasks();

    // Check if all tasks completed
    bool allCompleted = true;
    for (auto &pair : taskMap) {
        if (!pair.second.completed) {
            allCompleted = false;
            break;
        }
    }

    if (allCompleted) {
        std::cout << "\n?? Congratulations! All tasks completed successfully! ??\n";
    }

    return 0;
}